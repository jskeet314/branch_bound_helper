def tree_from_sequence(tree, generate_children_func):
    return tree
