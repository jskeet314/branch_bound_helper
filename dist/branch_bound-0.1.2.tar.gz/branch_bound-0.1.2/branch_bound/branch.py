def branch_format(tree):
    return "formatted branch"
