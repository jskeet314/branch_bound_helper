def get_initial_bound(tree, levels):
    return "lower bound"
