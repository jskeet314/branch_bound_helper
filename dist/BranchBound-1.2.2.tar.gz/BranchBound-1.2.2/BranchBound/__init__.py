name = "branch_bound"

if __name__ == "__main__":
    print("branch bound installed!")
